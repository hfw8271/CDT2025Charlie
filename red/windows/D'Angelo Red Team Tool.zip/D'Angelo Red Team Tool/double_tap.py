"""
This tool was made by Andy D'Angelo. ajd9252@rit.edu
CDT_Charlie
"""

import keyboard
import sys

def on_press(event):
    """ This function handles keyboard key presses. """
    global pressed_keys, exit_flag
    pressed_keys.add(event.name)
    
    # Stop the script if Ctrl + Alt + U is pressed
    if 'ctrl' in pressed_keys and 'alt' in pressed_keys and event.name == 'u':
        exit_flag = True
        # print("\nExiting...") For Debuggin
        keyboard.unhook_all()  # Clears the listenerss
        return False # Return to main
    
    # Handle backspace as usual
    if event.name == 'backspace':
        return True
    else:
        keyboard.send(event.name)  # Sends the character twice
    
    return False

def on_release(event):
    """ This function handles keyboard key releases. """
    global pressed_keys
    if event.name in pressed_keys:
        pressed_keys.remove(event.name)

def main():
    global pressed_keys, exit_flag
    pressed_keys = set()
    exit_flag = False
    # print("Key duplication started. Press Ctrl + Alt + U to stop.") For Debugging
    
    # Listen for keyboard events globally
    keyboard.hook(on_press, suppress=True)
    keyboard.on_release(on_release)
    
    while not exit_flag:
        pass
    sys.exit(0)

if __name__ == "__main__":
    main()